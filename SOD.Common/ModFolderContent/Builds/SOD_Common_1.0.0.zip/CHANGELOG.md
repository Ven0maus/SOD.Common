# CHANGELOG
**1.0.0**
- Added Base functionality methods
- Added Modelbased configuration
- Added UniverseLib build-in