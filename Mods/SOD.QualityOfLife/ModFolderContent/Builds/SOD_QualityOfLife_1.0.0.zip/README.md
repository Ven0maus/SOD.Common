# SOD.QualityOfLife
Gives each citizen a chance te be clumsy.

**Features**
- Chance to forget to lock door after closing it when its suppose to be locked.